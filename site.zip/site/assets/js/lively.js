/* Digi Mavs – lively layer: scroll reveals + light parallax. Safe to remove; the site works without it. */
(function () {
  var root = document.documentElement;
  var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (reduce || !('IntersectionObserver' in window)) { return; }

  var SEL = [
    '.dm-head', '.dm-card:not(.wow)', '.dm-logo-tile:not(.wow)', '.dm-client', '.dm-contact-card', '.dm-form',
    '.dm-founder', '.dm-step:not(.wow)', '.dm-cta', '.dm-coverage', '.dm-checks li', '.dm-pill--lg',
    '.dm-org__node', '.dm-map', '.dm-map-link', '.dm-about__visual', '.dm-stat', '.dm-lead', '.dm-title'
  ].join(',');

  var els = Array.prototype.slice.call(document.querySelectorAll(SEL)).filter(function (el) {
    // skip anything that sits inside something already being revealed, or inside the hero / marquee
    return !el.closest('.wow') && !el.closest('.dm-gallery') && !el.closest('.dm-hero');
  });
  var set = new Set(els);
  els = els.filter(function (el) {
    var p = el.parentElement;
    while (p) { if (set.has(p)) { return false; } p = p.parentElement; }
    return true;
  });

  root.classList.add('dm-js');
  var counts = new Map();
  els.forEach(function (el) {
    var n = counts.get(el.parentElement) || 0;
    counts.set(el.parentElement, n + 1);
    el.style.setProperty('--d', Math.min(n, 5) * 90 + 'ms');
    el.classList.add('dm-rv');
  });

  var io = new IntersectionObserver(function (entries) {
    entries.forEach(function (e) {
      if (!e.isIntersecting) { return; }
      var el = e.target;
      el.classList.add('in');
      io.unobserve(el);
      // hand control back to hover styles once the reveal finished
      setTimeout(function () { el.classList.remove('dm-rv', 'in'); el.style.removeProperty('--d'); }, 1500);
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -6% 0px' });
  els.forEach(function (el) { io.observe(el); });

  // never leave content hidden if something goes wrong
  setTimeout(function () { els.forEach(function (el) { el.classList.add('in'); }); }, 6000);

  // light parallax on the hero emblem / page-header
  var emblem = document.querySelector('.dm-hero__emblem');
  if (emblem) {
    var ticking = false;
    window.addEventListener('scroll', function () {
      if (ticking) { return; }
      ticking = true;
      requestAnimationFrame(function () {
        emblem.style.marginTop = Math.min(window.scrollY * 0.18, 120) + 'px';
        ticking = false;
      });
    }, { passive: true });
  }
})();
