DIGI MAVS LIMITED – WEBSITE
===========================
Open index.html in a browser to view the site (internet needed for the Google Fonts only).

Pages: index, about, services, clients, operations, contact, 404

CONTACT DETAILS (already set on every page)
  Phone:   +254 746 888 447
  Email:   info@digi-mavs.com
  Address: Fedha Plaza, Mpaka Road, Westlands, Nairobi (Google Map embedded on contact.html)
The contact form opens the visitor's email app addressed to info@digi-mavs.com (no server needed).

ANIMATION / ILLUSTRATIONS
  assets/css/lively.css, assets/js/lively.js  - animations, scrolling galleries, scroll reveals
  assets/images/rides/*.svg                   - animated motorbike rider illustrations
  Founder photo: assets/images/resources/ronald-kaleu.jpg (About page)

BRAND COLOURS (assets/css/digimavs.css, top of file)
  Navy #0a2a5e  |  Gold #d9960b
LOGO FILES: assets/images/resources/logo.png and logo-white.png
